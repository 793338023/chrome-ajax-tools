
## 0.0.3
1、支持JavaScript方式时，能通过arguments拿到原始接口信息（比如method、payload、originalResponse）

## 0.0.2
1、支持匹配HTTP请求方法（GET、POST、PUT、DELETE、HEAD、OPTIONS、CONNECT、TRACE、PATCH）

## 0.0.1
1、支持XMLHttpRequest、fetch  
2、支持正则表达式匹配  
3、支持返回结果Json、JavaScript方式编辑  
4、支持拦截404请求
